// js/script.js

document.getElementById('xmlFile')
  .addEventListener('change', function () {
    const file = this.files[0];
    if (!file) {
      fileInfo.textContent = 'No file selected.';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const xml = new DOMParser().parseFromString(reader.result, 'application/xml');
      const data = parseFlexibleTimeSeries(xml);

      if (!data.length) {
        alert('Could not find any energy intervals in your XML.');
        fileInfo.textContent = `Failed to load: ${file.name}`;
        return;
      }
      
      const format = detectXMLFormat(xml);
      console.log(`Detected format: ${format}`);
      // const data = parseFlexibleTimeSeries(xml);



      console.log('Parsed data:', data);
      fileInfo.textContent = `Showing: ${file.name} (${data.length} intervals)`;

      // clear prior charts
      d3.selectAll('svg').remove();


      // draw
      renderLineChart(data);
      renderRadialChart(data);
      renderHeatmap(data);
      renderGauge(data);
      renderAreaChart(data);
      renderBoxChart(data);
    };
    reader.readAsText(file);
  });

function parseFlexibleTimeSeries(xml) {
  const format = detectXMLFormat(xml);
  if (format === 'estonian') return parseEstonianFormat(xml);
  if (format === 'entsoe-flat') return parseENTSOEFlatFormat(xml);
  if (format === 'austrian') return parseAustrianFormat(xml);
  return [];
}


function detectXMLFormat(xml) {
  const ns = 'urn:entsoe.eu:wgedi:MyEnergyData:10:1';

  // 1. Estonian custom format: has <AccountTimeSeries>
  if (xml.getElementsByTagName('AccountTimeSeries').length > 0) {
    return 'estonian';
  }

  // 2. Austrian format: namespaced <TimeSeries> with multiple <Period> children and one <Point> per <Period>
  const nsTSList = xml.getElementsByTagNameNS(ns, 'TimeSeries');
  if (nsTSList.length > 0) {
    const periods = nsTSList[0].getElementsByTagNameNS(ns, 'Period');
    if (periods.length > 1 && periods[0].getElementsByTagNameNS(ns, 'Point').length === 1) {
      return 'austrian';
    }
  }

  // 3. ENTSO-E flat format: <TimeSeries> > <Period> > multiple <Point>
  const period = xml.querySelector('TimeSeries > Period');
  if (period && period.querySelectorAll('Point').length > 1) {
    return 'entsoe-flat';
  }

  return 'unknown';
}



function parseEstonianFormat(xml) {
  const period = xml.querySelector('AccountTimeSeries > Period');
  const resText = period.querySelector('Resolution').textContent.trim();
  const intervalMs = resText.includes('QH') ? 15 * 60 * 1000 : 60 * 60 * 1000;
  const start = d3.isoParse(period.querySelector('TimeInterval > start').textContent);
  return Array.from(period.querySelectorAll('AccountInterval')).map(ai => {
    const pos = +ai.querySelector('Pos').textContent;
    const qty = +ai.querySelector('OutQty').textContent;
    const date = new Date(start.getTime() + (pos - 1) * intervalMs);
    return { date, quantity: qty };
  });
}

function parseENTSOEFlatFormat(xml) {
  const period = xml.querySelector('TimeSeries > Period');
  const res = period.querySelector('Resolution')?.textContent.trim() || 'PT60M';
  const intervalMs = res.includes('15') ? 15 * 60 * 1000 : 60 * 60 * 1000;
  const start = d3.isoParse(period.querySelector('timeInterval > start').textContent);
  const points = period.querySelectorAll('Point');
  return Array.from(points).map(pt => {
    const pos = +pt.querySelector('position').textContent;
    const qty = +pt.querySelector('out_Quantity\\.quantity').textContent;
    const date = new Date(start.getTime() + (pos - 1) * intervalMs);
    return { date, quantity: qty };
  });
}

// function parseAustrianFormat(xml) {
function parseAustrianFormat(xml) {
  const ns = 'urn:entsoe.eu:wgedi:MyEnergyData:10:1';

  // Namespace-aware Austrian parsing
  const timeSeriesList = xml.getElementsByTagNameNS(ns, 'TimeSeries');
  if (timeSeriesList.length > 0) {
    const timeSeries = timeSeriesList[0];
    const periods = timeSeries.getElementsByTagNameNS(ns, 'Period');
    
    const parsed = Array.from(periods).map(p => {
      const timeInterval = p.getElementsByTagNameNS(ns, 'timeInterval')[0];
      const startEl = timeInterval?.getElementsByTagNameNS(ns, 'start')[0];
      const point = p.getElementsByTagNameNS(ns, 'Point')[0];
      const quantityEl = point?.getElementsByTagNameNS(ns, 'out_Quantity.quantity')[0];
      
      if (startEl && quantityEl) {
        const date = d3.isoParse(startEl.textContent);
        const quantity = parseFloat(quantityEl.textContent);
        return { date, quantity };
      }
      return null;
    }).filter(d => d !== null);

    return parsed;
  }

  return [];
}


  
  // 3a) standard line chart
  function renderLineChart(data) {
    const margin = { top:20, right:20, bottom:40, left:50 },
          w = 600 - margin.left - margin.right,
          h = 250 - margin.top - margin.bottom;
  
    const svg = d3.select('#lineChart')
      .append('svg')
        .attr('width', w + margin.left + margin.right)
        .attr('height', h + margin.top + margin.bottom)
      .append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`);
  
    const x = d3.scaleTime()
        .domain(d3.extent(data, d => d.date))
        .range([0, w]);
    const y = d3.scaleLinear()
        .domain([0, d3.max(data, d => d.quantity)]).nice()
        .range([h, 0]);
  
    svg.append('g')
        .attr('transform', `translate(0,${h})`)
        .call(d3.axisBottom(x).ticks(6));
    svg.append('g')
        .call(d3.axisLeft(y));
  
    const line = d3.line()
        .x(d => x(d.date))
        .y(d => y(d.quantity));
  
    svg.append('path')
        .datum(data)
        .attr('fill','none')
        .attr('stroke','steelblue')
        .attr('stroke-width',1.5)
        .attr('d', line);
  
    // tooltip
    const focus = svg.append('g').style('display','none');
    focus.append('circle').attr('r',4).attr('fill','orange');
    focus.append('rect')
        .attr('width',80).attr('height',24)
        .attr('x',8).attr('y',-12)
        .attr('fill','#fff').attr('stroke','#999');
    focus.append('text')
        .attr('x',12).attr('y',-2).attr('font-size','12px');
  
    svg.append('rect')
        .attr('width',w).attr('height',h)
        .style('fill','none')
        .style('pointer-events','all')
        .on('mouseover', () => focus.style('display',null))
        .on('mouseout',  () => focus.style('display','none'))
        .on('mousemove', (event) => {
          const xm = d3.pointer(event)[0],
                x0 = x.invert(xm),
                i  = d3.bisector(d => d.date).left(data, x0, 1),
                d0 = data[i-1], d1 = data[i] || d0,
                dClosest = (x0 - d0.date > d1.date - x0) ? d1 : d0;
          focus.attr('transform', `translate(${x(dClosest.date)},${y(dClosest.quantity)})`);
          focus.select('text').text(dClosest.quantity.toFixed(3) + ' kWh');
        });
  }
  
  // 3b) radial bar (avg per hour)
  function renderRadialChart(data) {
    const byHour = d3.rollup(
      data,
      v => d3.mean(v, d => d.quantity),
      d => d.date.getHours()
    );
    const vals = Array.from(byHour, ([hour, qty]) => ({ hour, qty }))
                      .sort((a,b) => a.hour - b.hour);
  
    const width = 300, height = 300,
          innerR = 30, outerR = width/2 - 10;
  
    const svg = d3.select('#radialChart')
      .append('svg')
        .attr('width',width).attr('height',height)
      .append('g')
        .attr('transform',`translate(${width/2},${height/2})`);
  
    const x = d3.scaleBand()
        .domain(vals.map(d => d.hour))
        .range([0,2*Math.PI])
        .align(0);
  
    const y = d3.scaleLinear()
        .domain([0, d3.max(vals,d => d.qty)])
        .range([innerR, outerR]);
  
    const arc = d3.arc()
        .innerRadius(innerR)
        .outerRadius(d => y(d.qty))
        .startAngle(d => x(d.hour))
        .endAngle(d => x(d.hour) + x.bandwidth())
        .padAngle(0.01)
        .padRadius(innerR);
  
    svg.selectAll('path')
      .data(vals)
      .enter().append('path')
        .attr('fill','tomato')
        .attr('d',arc)
      .append('title')
        .text(d => `Hour ${d.hour}: ${d.qty.toFixed(3)} kWh`);
  }
  
  // 3c) weekly heatmap
  function renderHeatmap(data) {
    const temp = d3.rollups(
      data,
      v => d3.mean(v, d => d.quantity),
      d => d.date.getDay(),
      d => d.date.getHours()
    );
    const cells = [];
    temp.forEach(([day, arr]) =>
      arr.forEach(([hr, avg]) => cells.push({ day, hr, avg }))
    );
  
    const cellSize = 20,
          m = { top:40, right:20, bottom:20, left:60 },
          W = 24*cellSize + m.left + m.right,
          H = 7*cellSize  + m.top  + m.bottom;
  
    const svg = d3.select('#heatmap')
      .append('svg')
        .attr('width',W).attr('height',H);
  
    const color = d3.scaleSequential(d3.interpolateYlGnBu)
        .domain(d3.extent(cells,d => d.avg));
  
    const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    // day labels
    svg.append('g')
      .selectAll('text')
      .data(days)
      .enter().append('text')
        .attr('x', m.left-5)
        .attr('y',(d,i)=>m.top + i*cellSize + cellSize*0.7)
        .attr('text-anchor','end')
        .text(d=>d);
  
    // hour labels
    svg.append('g')
      .selectAll('text.hour')
      .data(d3.range(24))
      .enter().append('text')
        .attr('x', d=>m.left + d*cellSize + cellSize/2)
        .attr('y', m.top-5)
        .attr('text-anchor','middle')
        .text(d=>d);
  
    // cells
    svg.append('g')
      .selectAll('rect')
      .data(cells)
      .enter().append('rect')
        .attr('x', d=>m.left + d.hr*cellSize)
        .attr('y', d=>m.top  + d.day*cellSize)
        .attr('width', cellSize)
        .attr('height',cellSize)
        .attr('fill',d=>color(d.avg))
      .append('title')
        .text(d=>`${days[d.day]}, ${d.hr}:00 → ${d.avg.toFixed(3)} kWh`);
  }
  
  // 3d) average gauge
  function renderGauge(data) {
    const avg = d3.mean(data, d => d.quantity),
          max = d3.max(data, d => d.quantity);
  
    const W = 250, H = 150, r = Math.min(W,H)/2;
  
    const svg = d3.select('#gauge')
      .append('svg')
        .attr('width',W).attr('height',H+20)
      .append('g')
        .attr('transform',`translate(${W/2},${H})`);
  
    // background
    const bg = d3.arc()
      .innerRadius(r*0.7)
      .outerRadius(r)
      .startAngle(-Math.PI/2)
      .endAngle( Math.PI/2);
  
    svg.append('path')
        .attr('d',bg())
        .attr('fill','#eee');
  
    // foreground
    const fg = d3.arc()
      .innerRadius(r*0.7)
      .outerRadius(r)
      .startAngle(-Math.PI/2)
      .endAngle(-Math.PI/2 + (avg/max)*Math.PI);
  
    svg.append('path')
        .attr('d',fg())
        .attr('fill','steelblue');
  
    // label
    svg.append('text')
        .attr('text-anchor','middle')
        .attr('dy','-0.5em')
        .attr('font-size','16px')
        .text(`Avg: ${avg.toFixed(3)} kWh`);
  }
  /* ====================================================================== *
 * 4)  CUMULATIVE AREA CHART                                              *
 * ====================================================================== */
    function renderAreaChart(data) {
        // compute cumulative sum
        let running = 0;
        const cum = data.map(d => ({ date: d.date, total: running += d.quantity }));
    
        const margin = { top: 20, right: 20, bottom: 40, left: 50 },
            w = 600 - margin.left - margin.right,
            h = 250 - margin.top - margin.bottom;
    
        const svg = d3.select('#areaChart')
        .append('svg')
            .attr('width', w + margin.left + margin.right)
            .attr('height', h + margin.top + margin.bottom)
        .append('g')
            .attr('transform', `translate(${margin.left},${margin.top})`);
    
        const x = d3.scaleTime()
            .domain(d3.extent(cum, d => d.date))
            .range([0, w]);
    
        const y = d3.scaleLinear()
            .domain([0, d3.max(cum, d => d.total)]).nice()
            .range([h, 0]);
    
        const area = d3.area()
            .x(d => x(d.date))
            .y0(h)
            .y1(d => y(d.total));
    
        svg.append('path')
            .datum(cum)
            .attr('fill', 'rgba(70,130,180,0.5)')
            .attr('stroke', 'steelblue')
            .attr('stroke-width', 1.2)
            .attr('d', area);
    
        // axes
        svg.append('g')
            .attr('transform', `translate(0,${h})`)
            .call(d3.axisBottom(x).ticks(6));
        svg.append('g')
            .call(d3.axisLeft(y));
    
        // simple tooltip
        const tip = svg.append('g').style('display', 'none');
        tip.append('circle').attr('r', 3).attr('fill', 'navy');
        tip.append('text')
        .attr('x', 6).attr('dy', '.35em')
        .attr('font-size', '12px');
    
        svg.append('rect')
            .attr('width', w).attr('height', h)
            .style('fill', 'none').style('pointer-events', 'all')
            .on('mouseover', () => tip.style('display', null))
            .on('mouseout',  () => tip.style('display', 'none'))
            .on('mousemove', (event) => {
            const xm = d3.pointer(event)[0];
            const t  = x.invert(xm);
            const i  = d3.bisector(d => d.date).left(cum, t, 1);
            const p0 = cum[i-1], p1 = cum[i] || p0;
            const p  = (t - p0.date > p1.date - t) ? p1 : p0;
            tip.attr('transform', `translate(${x(p.date)},${y(p.total)})`);
            tip.select('text').text(p.total.toFixed(2) + ' kWh');
            });
    
        /* ─── BRUSH that SYNCS with main line chart ─── */
        const brush = d3.brushX()
            .extent([[0,0],[w,h]])
            .on('brush end', ({selection}) => {
            if (!selection) return;
            const [x0,x1] = selection.map(x.invert);
            // emit event so lineChart can zoom
            svg.dispatch('brushZoom', { detail: { x0, x1 } });
            });
    
        svg.append('g').attr('class', 'brush').call(brush);
    }
    
    /* ====================================================================== *
    * 5)  BOX-AND-WHISKER BY HOUR                                            *
    * ====================================================================== */
    function renderBoxChart(data) {
    
        /* -------- compute 5-number summaries per hour -------- */
        const grouped = d3.groups(data, d => d.date.getHours());
        const stats = grouped.map(([hr, arr]) => {
        const q = arr.map(d => d.quantity).sort(d3.ascending);
        return {
            hour: +hr,
            min : d3.min(q),
            q1  : d3.quantileSorted(q, .25),
            med : d3.quantileSorted(q, .5),
            q3  : d3.quantileSorted(q, .75),
            max : d3.max(q)
        };
        });
    
        const margin = { top: 20, right: 20, bottom: 30, left: 40 },
            w = 600 - margin.left - margin.right,
            h = 250 - margin.top - margin.bottom;
    
        const svg = d3.select('#boxChart')
        .append('svg')
            .attr('width', w + margin.left + margin.right)
            .attr('height', h + margin.top + margin.bottom)
        .append('g')
            .attr('transform', `translate(${margin.left},${margin.top})`);
    
        const x = d3.scaleBand()
            .domain(stats.map(d => d.hour))
            .range([0, w])
            .paddingInner(0.3)
            .paddingOuter(0.1);
    
        const y = d3.scaleLinear()
            .domain([0, d3.max(stats, d => d.max)]).nice()
            .range([h, 0]);
    
        // boxes
        const g = svg.selectAll('g.box').data(stats).enter().append('g')
                    .attr('class','box')
                    .attr('transform', d => `translate(${x(d.hour)},0)`);
    
        // vertical line (min-max)
        g.append('line')
        .attr('y1', d => y(d.min))
        .attr('y2', d => y(d.max))
        .attr('x1', x.bandwidth()/2)
        .attr('x2', x.bandwidth()/2)
        .attr('stroke', '#555');
    
        // rectangle (q1-q3)
        g.append('rect')
        .attr('y',  d => y(d.q3))
        .attr('height', d => y(d.q1) - y(d.q3))
        .attr('width', x.bandwidth())
        .attr('fill', '#3182bd');
    
        // median line
        g.append('line')
        .attr('y1', d => y(d.med))
        .attr('y2', d => y(d.med))
        .attr('x1', 0)
        .attr('x2', x.bandwidth())
        .attr('stroke', '#fff')
        .attr('stroke-width', 2);
    
        // axes
        svg.append('g')
        .attr('transform', `translate(0,${h})`)
        .call(d3.axisBottom(x).tickFormat(d => d));
        svg.append('g')
        .call(d3.axisLeft(y));
    
        // tooltip
        const tip = d3.select('body')
            .append('div')
            .style('position','absolute')
            .style('background','#fff')
            .style('border','1px solid #777')
            .style('border-radius','4px')
            .style('padding','4px 8px')
            .style('pointer-events','none')
            .style('font-size','.85rem')
            .style('opacity',0);
    
        g.on('mouseover', function(_,d){
            tip.style('opacity',1)
                .html(`Hour ${d.hour}:00<br>
                    min ${d.min}<br>
                    Q1 ${d.q1}<br>
                    median ${d.med}<br>
                    Q3 ${d.q3}<br>
                    max ${d.max}`)
        })
        .on('mousemove', (e)=> tip.style('left', e.pageX+10+'px')
                                .style('top', e.pageY-28+'px'))
        .on('mouseout',  ()=> tip.style('opacity',0));
    }
  
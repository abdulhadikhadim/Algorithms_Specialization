# Energy Consumption Dashboard

This dashboard allows you to load CIM-formatted XML files containing quarter-hourly or hourly energy consumption data and explore your usage through six powerful, interactive D3.js charts.

## 🔍 Supported CIM XML Formats

- **Estonian format**: `<AccountTimeSeries>` with `<AccountInterval>` entries
- **Austrian (ENTSO-E namespaced)**: `<TimeSeries>` with multiple `<Period>` blocks, each containing one `<Point>`
- **ENTSO-E flat**: `<TimeSeries>` with one `<Period>` and multiple `<Point>` children

## 📊 Included Charts

1. **Consumption Over Time** – Time-series line chart (kWh vs. timestamp)  
2. **Radial Consumption by Hour** – Hourly averages displayed in a circular bar chart  
3. **Weekly Heatmap (avg kWh)** – Day-of-week × Hour-of-day color grid  
4. **Average Consumption Gauge** – Visual gauge of average vs. peak load  
5. **Cumulative Energy (kWh)** – Area chart showing energy accumulation through the day  
6. **Box & Whisker by Hour** – Distribution of quarter-hourly values for each hour

## 🚀 Getting Started

1. Clone or download this repository  
2. Run a local server in the folder (e.g., `python -m http.server`)  
3. Open `index.html` in your browser  
4. Click **Choose File** and upload any compatible CIM XML  
5. All charts will render automatically based on the detected format

## 📁 File Structure

.
├── css/
│ └── style.css # Dashboard styling
├── data/
│ ├── EstonianData.xml # Flat ENTSO-E structure (sample)
│ ├── AustrianData.xml # Namespace-aware Period-by-Period format
│ └── EE_Test-Data_QH.xml # AccountTimeSeries Estonian format
├── js/
│ └── script.js # Format detection, XML parsing, D3 rendering
├── index.html # Main dashboard UI
└── README.md # This document

markdown
Copy
Edit

## 📦 Dependencies

- [D3.js v7](https://d3js.org/)  
- Modern browser with ES6+ support

## 🧠 How It Works

### Format Detection
The system automatically determines the file’s structure:
- Looks for `<AccountTimeSeries>` for Estonian style
- Uses namespace-aware lookup for Austrian style
- Falls back to detecting flat `<TimeSeries><Period><Point>` layout for ENTSO-E flat

### Timestamp Handling
- **Parsing:** Timestamps like `2022-11-09T00:00:00+01:00` are parsed with `d3.isoParse`, preserving timezone offsets  
- **Resolution:** Determined via `<Resolution>` tag (`QH`, `PT60M`, etc.)  
- **Position-based Mapping:** Each data point’s timestamp is derived using its position (`Pos`) or interval block's `<start>` time  
  ```js
  new Date(startDate.getTime() + (pos - 1) * intervalMs);

### 3) Dashboard Report

#### What’s in the Dashboard
The Energy Consumption Dashboard is a single‐page web app that reads a CIM-formatted XML file containing quarter-hourly energy consumption (`<AccountInterval>` entries) and visualizes the data through six distinct chart types. It features:

- A **file picker** to load any valid CIM XML.
- An **info panel** showing the filename and number of intervals.
- A **responsive two-column layout** that adapts to screen size.
- Six D3.js charts covering trend, distribution, diurnal patterns, and accumulation.

#### Why These Graphs
- **Trend Analysis (Line Chart):** Detect day-long usage trends, spikes during peak hours, and drops at off-peak times.  
- **Hourly Patterns (Radial Chart):** Present average consumption per clock hour in a visually intuitive radial form, reinforcing the hours of highest demand.  
- **Pattern Recognition (Heatmap):** Combine daily and hourly dimensions to spot consistent patterns or anomalies, especially over multiple days.  
- **Summarized Load (Gauge):** Quickly assess the “typical” load relative to the day’s maximum, useful for benchmarking performance against targets.  
- **Cumulative View (Area Chart):** Track total energy accrued over time to understand how quickly you reach key consumption milestones.  
- **Variability Inspection (Box & Whisker):** Examine intra-hour variability—are some hours more stable than others? Find out if certain hours have erratic consumption.

Together, these views provide a comprehensive overview: overall trajectory, average behaviors, detailed distributions, and cumulative totals.


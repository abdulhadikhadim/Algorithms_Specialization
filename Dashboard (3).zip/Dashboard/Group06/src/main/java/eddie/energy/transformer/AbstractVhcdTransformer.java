package eddie.energy.transformer;

import javax.xml.bind.JAXBElement;
import schemas.eu.MyEnergyDataMarketDocument;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import schemas.eu.ObjectFactory;

public abstract class AbstractVhcdTransformer implements IVhcdTransformer {
    final static SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mmZZ");
    static JAXBContext ctx;

    static {
        try {
            ctx = JAXBContext.newInstance(MyEnergyDataMarketDocument.class);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    static Marshaller ms;

    static {
        try {
            ms = ctx.createMarshaller();
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    protected AbstractVhcdTransformer() throws JAXBException {
        ms.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    }

    // default method from Abstract Class
    // TODO return to this when XMLROOT Annotation error is fixed

//    public static String getDocAsString(MyEnergyDataMarketDocument doc) throws JAXBException {
//        StringWriter writer = new StringWriter();
//        ms.marshal(doc, writer);
//        return writer.toString();
//    }


    //Method that assigns the XML ROOt element
    // wrapper needed because of XMLRootName Annotation error
    //Estonian wokrs without this.
    // TODO return to default when XMLROOT Annotation error is fixed
        public static String getDocAsString(MyEnergyDataMarketDocument doc) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(MyEnergyDataMarketDocument.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        ObjectFactory factory = new ObjectFactory();
        JAXBElement<MyEnergyDataMarketDocument> element = factory.createMyEnergyDataMarketDocument(doc);

        StringWriter sw = new StringWriter();
        marshaller.marshal(element, sw);
        return sw.toString();
    }

}

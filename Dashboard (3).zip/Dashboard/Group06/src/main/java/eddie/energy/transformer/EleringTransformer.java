package eddie.energy.transformer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.UUID;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.Duration;
import javax.xml.datatype.XMLGregorianCalendar;
import schemas.eu.*;
import schemas.region.ee.AccountInterval;
import schemas.region.ee.EnergyReport;

public class EleringTransformer extends AbstractVhcdTransformer{

  EnergyReport energyReport;
  final JAXBContext estonianContext = JAXBContext.newInstance(EnergyReport.class);
  final Unmarshaller estonianContextUnmarshaller = estonianContext.createUnmarshaller();

  public EleringTransformer() throws JAXBException {
    super();
  }

  @Override
  public void loadFromFile(File file) throws IOException, JAXBException{
    energyReport = (EnergyReport) estonianContextUnmarshaller.unmarshal(new FileInputStream(file));
  }

  @Override
  public void loadReceivedData(String receivedData) throws JAXBException{
    energyReport = (EnergyReport) estonianContextUnmarshaller.unmarshal(new StringReader(receivedData));
  }

  //only calls the logic function with the data
  @Override
  public MyEnergyDataMarketDocument getMappedMarketDocument(File file)
      throws JAXBException, IOException {
    loadFromFile(file);
    return getMappedMarketDocument();
  }

  //only calls the logic function with the data
  @Override
  public MyEnergyDataMarketDocument getMappedMarketDocument(String receivedData)
      throws JAXBException {
      loadReceivedData(receivedData);
    return getMappedMarketDocument();
  }

  // TODO delete seconds from date better than this
  private String formatDateWithoutSecondsInUTC(XMLGregorianCalendar date) {
    String utcDate = date.normalize().toString();
    return utcDate.substring(0, 16) + utcDate.substring(19);
  }

  @Override
  public MyEnergyDataMarketDocument getMappedMarketDocument() {

    MyEnergyDataMarketDocument doc = new MyEnergyDataMarketDocument();
    doc.setMRID(energyReport.getDocumentIdentification());

    //TODO not sure if the id's should go into the name field or mRID
    // or via PartyIDString
    //doc.setSenderMarketParticipantName(energyReport.getSenderIdentification());
    //doc.setReceiverMarketParticipantName(energyReport.getReceiverIdentification());
    PartyIDString partyIDString = new PartyIDString();
    partyIDString.setValue(energyReport.getSenderIdentification());
    partyIDString.setCodingScheme("NEE");
    doc.setSenderMarketParticipantMRID(partyIDString);

    //reciever ID
    partyIDString.setValue(energyReport.getReceiverIdentification());
    doc.setReceiverMarketParticipantMRID(partyIDString);

    // setting Document Time in UTC
    doc.setCreatedDateTime(energyReport.getDocumentDateTime().normalize());

    //copied from the austrian converter - Is this still right?
    doc.setSenderMarketParticipantName("MDA");
    doc.setReceiverMarketParticipantName("EP");

    //one AccountTimeSeries maps to on timeSeries in EU
    TimeSeries ts = new TimeSeries();

    //max string lentgh = 35
    ts.setMRID(UUID.randomUUID().toString().substring(0,35));
    ts.setMeasurementUnitName("KWH");
    //setting to code for Active Energy according to codelist
    ts.setProduct("8716867000030");

    //in estonian case only one period
    SeriesPeriod period = new SeriesPeriod();

    // seconds are not allowed here in the time format here
    ESMPDateTimeInterval intv = new ESMPDateTimeInterval();
    String start = formatDateWithoutSecondsInUTC(energyReport.getAccountTimeSeries().getPeriod().getTimeInterval().getStart());
    String end = formatDateWithoutSecondsInUTC(energyReport.getAccountTimeSeries().getPeriod().getTimeInterval().getEnd());

    intv.setStart(start);
    intv.setEnd(end);

    //TODO: Is setting for period and the whole document really necessary?
    period.setTimeInterval(intv);
    doc.setPeriodTimeInterval(intv);

    // setting the Resolution type
    // TODO: Is there an easier Solution?
    try {
      Duration duration = DatatypeFactory.newInstance().newDuration("PT15M");
      period.setResolution(duration);
    } catch (DatatypeConfigurationException e) {
      throw new RuntimeException(e);
    }

    // mapping the data point intervals
    for (AccountInterval dataSpan : energyReport.getAccountTimeSeries().getPeriod().getAccountInterval() ) {
      Point point = new Point();
      point.setPosition(dataSpan.getPos().intValue());
      point.setOutQuantityQuantity(dataSpan.getMeasurementUnit().getOutQty());
      point.setInQuantityQuantity(dataSpan.getMeasurementUnit().getInQty());
      period.getPoint().add(point);
    }

    ts.getPeriod().add(period);
    // technical measurepoint
    MeasurementPointIDString mpid = new MeasurementPointIDString();
    //coding scheme for estonia according to ENTSO-E codelist
    mpid.setCodingScheme("NEE");
    // accountingPoint as MeasurementPointID
    mpid.setValue(energyReport.getAccountTimeSeries().getAccountingPoint());

    //market measurepoint
    MarketEvaluationPoint ep = new MarketEvaluationPoint();
    ep.setMRID(mpid);
    ts.getMarketEvaluationPoint().add(ep);

    doc.getTimeSeries().add(ts);

    return doc;
  }
}

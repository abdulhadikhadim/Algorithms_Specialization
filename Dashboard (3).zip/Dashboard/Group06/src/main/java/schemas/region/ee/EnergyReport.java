
package schemas.region.ee;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}DocumentIdentification"/&gt;
 *         &lt;element ref="{}SenderIdentification"/&gt;
 *         &lt;element ref="{}ReceiverIdentification"/&gt;
 *         &lt;element ref="{}DocumentDateTime"/&gt;
 *         &lt;element ref="{}AccountTimeSeries"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "documentIdentification",
    "senderIdentification",
    "receiverIdentification",
    "documentDateTime",
    "accountTimeSeries"
})
@XmlRootElement(name = "EnergyReport")
public class EnergyReport {

    @XmlElement(name = "DocumentIdentification", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String documentIdentification;
    @XmlElement(name = "SenderIdentification", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String senderIdentification;
    @XmlElement(name = "ReceiverIdentification", required = true)
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    @XmlSchemaType(name = "NCName")
    protected String receiverIdentification;
    @XmlElement(name = "DocumentDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar documentDateTime;
    @XmlElement(name = "AccountTimeSeries", required = true)
    protected AccountTimeSeries accountTimeSeries;

    /**
     * Gets the value of the documentIdentification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentIdentification() {
        return documentIdentification;
    }

    /**
     * Sets the value of the documentIdentification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentIdentification(String value) {
        this.documentIdentification = value;
    }

    /**
     * Gets the value of the senderIdentification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenderIdentification() {
        return senderIdentification;
    }

    /**
     * Sets the value of the senderIdentification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSenderIdentification(String value) {
        this.senderIdentification = value;
    }

    /**
     * Gets the value of the receiverIdentification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiverIdentification() {
        return receiverIdentification;
    }

    /**
     * Sets the value of the receiverIdentification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiverIdentification(String value) {
        this.receiverIdentification = value;
    }

    /**
     * Gets the value of the documentDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDocumentDateTime() {
        return documentDateTime;
    }

    /**
     * Sets the value of the documentDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDocumentDateTime(XMLGregorianCalendar value) {
        this.documentDateTime = value;
    }

    /**
     * Gets the value of the accountTimeSeries property.
     * 
     * @return
     *     possible object is
     *     {@link AccountTimeSeries }
     *     
     */
    public AccountTimeSeries getAccountTimeSeries() {
        return accountTimeSeries;
    }

    /**
     * Sets the value of the accountTimeSeries property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountTimeSeries }
     *     
     */
    public void setAccountTimeSeries(AccountTimeSeries value) {
        this.accountTimeSeries = value;
    }

}


package schemas.region.ee;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{}OutQty"/&gt;
 *         &lt;element ref="{}InQty"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "outQty",
    "inQty"
})
@XmlRootElement(name = "MeasurementUnit")
public class MeasurementUnit {

    @XmlElement(name = "OutQty", required = true)
    protected BigDecimal outQty;
    @XmlElement(name = "InQty", required = true)
    protected BigDecimal inQty;

    /**
     * Gets the value of the outQty property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOutQty() {
        return outQty;
    }

    /**
     * Sets the value of the outQty property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOutQty(BigDecimal value) {
        this.outQty = value;
    }

    /**
     * Gets the value of the inQty property.
     * 
     * @return
     *     possible object is
     *     {@link InQty }
     *     
     */
    public BigDecimal getInQty() {
        return inQty;
    }

    /**
     * Sets the value of the inQty property.
     * 
     * @param value
     *     allowed object is
     *     {@link InQty }
     *     
     */
    public void setInQty(BigDecimal value) {
        this.inQty = value;
    }

}

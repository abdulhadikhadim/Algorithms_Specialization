
package schemas.region.ee;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the ee package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DocumentIdentification_QNAME = new QName("", "DocumentIdentification");
    private final static QName _SenderIdentification_QNAME = new QName("", "SenderIdentification");
    private final static QName _ReceiverIdentification_QNAME = new QName("", "ReceiverIdentification");
    private final static QName _DocumentDateTime_QNAME = new QName("", "DocumentDateTime");
    private final static QName _AccountingPoint_QNAME = new QName("", "AccountingPoint");
    private final static QName _Start_QNAME = new QName("", "start");
    private final static QName _End_QNAME = new QName("", "end");
    private final static QName _Resolution_QNAME = new QName("", "Resolution");
    private final static QName _Pos_QNAME = new QName("", "Pos");
    private final static QName _OutQty_QNAME = new QName("", "OutQty");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: ee
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link EnergyReport }
     * 
     */
    public EnergyReport createEnergyReport() {
        return new EnergyReport();
    }

    /**
     * Create an instance of {@link AccountTimeSeries }
     * 
     */
    public AccountTimeSeries createAccountTimeSeries() {
        return new AccountTimeSeries();
    }

    /**
     * Create an instance of {@link Period }
     * 
     */
    public Period createPeriod() {
        return new Period();
    }

    /**
     * Create an instance of {@link TimeInterval }
     * 
     */
    public TimeInterval createTimeInterval() {
        return new TimeInterval();
    }

    /**
     * Create an instance of {@link AccountInterval }
     * 
     */
    public AccountInterval createAccountInterval() {
        return new AccountInterval();
    }

    /**
     * Create an instance of {@link MeasurementUnit }
     * 
     */
    public MeasurementUnit createMeasurementUnit() {
        return new MeasurementUnit();
    }

    /**
     * Create an instance of {@link InQty }
     * 
     */
    public InQty createInQty() {
        return new InQty();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "DocumentIdentification")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    public JAXBElement<String> createDocumentIdentification(String value) {
        return new JAXBElement<String>(_DocumentIdentification_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "SenderIdentification")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    public JAXBElement<String> createSenderIdentification(String value) {
        return new JAXBElement<String>(_SenderIdentification_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "ReceiverIdentification")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    public JAXBElement<String> createReceiverIdentification(String value) {
        return new JAXBElement<String>(_ReceiverIdentification_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "DocumentDateTime")
    public JAXBElement<XMLGregorianCalendar> createDocumentDateTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_DocumentDateTime_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "AccountingPoint")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    public JAXBElement<String> createAccountingPoint(String value) {
        return new JAXBElement<String>(_AccountingPoint_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "start")
    public JAXBElement<XMLGregorianCalendar> createStart(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_Start_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "end")
    public JAXBElement<XMLGregorianCalendar> createEnd(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_End_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "Resolution")
    @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
    public JAXBElement<String> createResolution(String value) {
        return new JAXBElement<String>(_Resolution_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "Pos")
    public JAXBElement<BigInteger> createPos(BigInteger value) {
        return new JAXBElement<BigInteger>(_Pos_QNAME, BigInteger.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "OutQty")
    public JAXBElement<BigDecimal> createOutQty(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_OutQty_QNAME, BigDecimal.class, null, value);
    }

}

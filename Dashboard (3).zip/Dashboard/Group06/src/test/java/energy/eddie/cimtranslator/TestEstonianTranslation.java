package energy.eddie.cimtranslator;

import eddie.energy.transformer.AbstractVhcdTransformer;
import eddie.energy.transformer.EleringTransformer;
import javax.xml.bind.JAXBContext;
import org.junit.jupiter.api.Test;
import schemas.eu.MyEnergyDataMarketDocument;

import java.io.File;
import schemas.eu.ObjectFactory;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;

public class TestEstonianTranslation {

  @Test
  public void testDailyValues() throws Exception {

    String inputDataPath = "./src/test/resources/EE/EE_Test-Data_QH.xml";
    String outputDataPath = "./src/test/resources/EE/output.xml";

    EleringTransformer eleringTransformer = new EleringTransformer();

    MyEnergyDataMarketDocument doc = eleringTransformer.getMappedMarketDocument(new File(inputDataPath));

    System.out.println(AbstractVhcdTransformer.getDocAsString(doc));

    //print to file for locally validating against schema
    // wrapper needed because of XMLRootName Annotation error
    // uncomment below to write to file
    JAXBContext context = JAXBContext.newInstance(MyEnergyDataMarketDocument.class);
    Marshaller marshaller = context.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

    ObjectFactory factory = new ObjectFactory();
    JAXBElement<MyEnergyDataMarketDocument> element = factory.createMyEnergyDataMarketDocument(doc);

    File outputFile = new File(outputDataPath);
    marshaller.marshal(element, outputFile);

  }
}
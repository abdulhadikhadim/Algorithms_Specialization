# Energy Consumption Dashboard

This dashboard lets you load a CIM XML file of quarter-hourly energy measurements and explore your consumption through six different chart types.

## Included Charts

1. **Consumption Over Time** – Time-series line chart of kWh vs. timestamp.  
2. **Radial Consumption by Hour** – Average kWh per hour in a circular bar layout.  
3. **Weekly Heatmap (avg kWh)** – Day‐of‐week × Hour‐of‐day colored grid of average consumption.  
4. **Average Consumption Gauge** – Semi‐circular gauge comparing the average reading to the daily peak.  
5. **Cumulative Energy (kWh)** – Area chart of running total consumption through the day.  
6. **Box & Whisker by Hour** – Distribution of quarter-hour readings for each hour.

## Getting Started

1. Clone or download this repository.  
2. Serve the folder over HTTP (e.g., `python -m http.server`) and open `index.html` in your browser.  
3. Click **Choose File** to load any CIM XML with `<AccountTimeSeries>`.  
4. The six charts will render and update automatically.

## File Structure

├── css/
│ └── style.css # Dashboard styling
├── data/
│ └── EE_Test-Data_QH.xml # Sample XML to test
├── js/
│ └── script.js # XML parsing & D3 chart rendering
├── index.html # Main dashboard page
└── README.md # This document

markdown
Copy
Edit

## Dependencies

- [D3.js v7](https://d3js.org/)  
- Modern browser supporting ES6 and `fetch`

---

### 3) Dashboard Report

#### What’s in the Dashboard
The Energy Consumption Dashboard is a single‐page web app that reads a CIM-formatted XML file containing quarter-hourly energy consumption (`<AccountInterval>` entries) and visualizes the data through six distinct chart types. It features:

- A **file picker** to load any valid CIM XML.
- An **info panel** showing the filename and number of intervals.
- A **responsive two-column layout** that adapts to screen size.
- Six D3.js charts covering trend, distribution, diurnal patterns, and accumulation.

#### Why These Graphs
- **Trend Analysis (Line Chart):** Detect day-long usage trends, spikes during peak hours, and drops at off-peak times.  
- **Hourly Patterns (Radial Chart):** Present average consumption per clock hour in a visually intuitive radial form, reinforcing the hours of highest demand.  
- **Pattern Recognition (Heatmap):** Combine daily and hourly dimensions to spot consistent patterns or anomalies, especially over multiple days.  
- **Summarized Load (Gauge):** Quickly assess the “typical” load relative to the day’s maximum, useful for benchmarking performance against targets.  
- **Cumulative View (Area Chart):** Track total energy accrued over time to understand how quickly you reach key consumption milestones.  
- **Variability Inspection (Box & Whisker):** Examine intra-hour variability—are some hours more stable than others? Find out if certain hours have erratic consumption.

Together, these views provide a comprehensive overview: overall trajectory, average behaviors, detailed distributions, and cumulative totals.

#### Handling Timestamps
- **Parsing:** The XML’s `<TimeInterval><start>` string (e.g. `2022-11-09T00:00:00+01:00`) is parsed as a JavaScript `Date`, preserving timezone offsets.  
- **Resolution:** The `<Resolution>` tag (`QH` or `PT60M`) determines the interval period (15 minutes or 60 minutes).  
- **Position Mapping:** Each `<AccountInterval>` has a 1-based `<Pos>`. We subtract one and multiply by the interval length (ms) to compute each reading’s exact timestamp:  
  ```js
  new Date(startDate.getTime() + (pos - 1) * intervalMs)